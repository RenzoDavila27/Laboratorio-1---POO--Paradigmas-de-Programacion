public class Crucero extends Fichas{
    

    public Crucero(){
        super(2, 'C');
    }

}
