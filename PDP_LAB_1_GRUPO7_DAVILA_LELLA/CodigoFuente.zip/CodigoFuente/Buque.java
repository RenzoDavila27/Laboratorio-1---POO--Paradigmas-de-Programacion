public class Buque extends Fichas{

    public Buque(){
        super(4, 'B');
    }

}
