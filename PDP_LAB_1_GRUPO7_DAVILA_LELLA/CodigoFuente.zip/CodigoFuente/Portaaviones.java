public class Portaaviones extends Fichas {
    
    public Portaaviones(){
        super(5, 'P');
    }


}
