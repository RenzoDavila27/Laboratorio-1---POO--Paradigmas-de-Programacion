public class Restos extends Fichas {
    
    public Restos(char identificador){
        super(1, identificador);
    }
}
