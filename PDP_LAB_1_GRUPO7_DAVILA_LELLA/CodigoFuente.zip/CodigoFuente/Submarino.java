public class Submarino extends Fichas{
    
    public Submarino(){
        super(3, 'S');
    }

}
