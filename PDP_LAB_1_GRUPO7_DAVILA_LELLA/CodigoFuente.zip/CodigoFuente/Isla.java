public abstract class Isla extends Fichas {

    public Isla(int t){
        super(t,'I');
    }

}
