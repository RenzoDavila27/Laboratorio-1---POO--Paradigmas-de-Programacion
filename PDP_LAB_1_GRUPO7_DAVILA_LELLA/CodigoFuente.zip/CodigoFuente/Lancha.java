
public class Lancha extends Fichas{

    public Lancha(){
        super(1, 'L');

    }
    
}