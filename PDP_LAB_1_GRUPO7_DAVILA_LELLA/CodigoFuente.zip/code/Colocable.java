public interface Colocable{ //Esto lo hacemos por si en un futuro queremos implementar diferentes formas de posicionamiento de barcos
    void colocar(Jugador p1, Posicion position, int option);
}
