/**
 * La clase Buque representa un barco de tipo buque que extiende la clase Fichas.
 */
public class Buque extends Fichas{
    /**
     * Constructor que crea un Buque con tamanio 4 y un identificador 'B'.
     */
    public Buque(){
        super(4, 'B');
    }

}
