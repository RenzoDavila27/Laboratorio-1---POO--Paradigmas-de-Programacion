/**
 * La clase Portaaviones representa un barco de tipo submarino que extiende la clase Fichas.
 */
public class Submarino extends Fichas{
    /**
     *  Constructor que crea un Submarino con tamanio 3 y un identificador 'S'
     */
     
    public Submarino(){
        super(3, 'S');
    }

}
