/**
 * La clase Restos reprenseta el disparo acertado a unos de los barcos o islas de tu tablero defensor
 */
public class Restos extends Fichas {
    /**
     * Constructor que crea Restos de tamanio 1 y un identificador que puede ser X o O
     * @param identificador Identificador que se le va a poner a los restos
     */
    public Restos(char identificador){
        super(1, identificador);
    }

}
