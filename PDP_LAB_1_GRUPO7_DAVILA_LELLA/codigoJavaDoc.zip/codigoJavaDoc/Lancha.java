/**
 * La clase Lancha representa un barco de tipo lancha que extiende la clase Fichas.
 */
public class Lancha extends Fichas{
     /**
     * Constructor que crea una Lancha con tamanio 1 y un identificador 'L'.
     */
    public Lancha(){
        super(1, 'L');
    }

}