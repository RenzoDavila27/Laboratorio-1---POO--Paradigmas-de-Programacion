
/**
 * La clase Crucero representa un barco de tipo crucero que extiende la clase Fichas.
 */
public class Crucero extends Fichas{
    
    
    /**
     *Constructor que crea un Crucero con tamanio 2 y un identificador 'C'
     */
    public Crucero(){
        super(2, 'C');
    }

}
