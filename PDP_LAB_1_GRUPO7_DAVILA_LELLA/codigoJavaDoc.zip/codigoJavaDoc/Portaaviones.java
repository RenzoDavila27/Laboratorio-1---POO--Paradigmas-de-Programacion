/**
 * La clase Portaaviones representa un barco de tipo Portaaviones que extiende la clase Fichas.
 */
public class Portaaviones extends Fichas {
    
     /**
     *Constructor que crea un Portaaviones con tamanio 5 y un identificador 'P'
     */
    public Portaaviones(){
        super(5, 'P');
    }

}
