/**
 * Interface de Colocables en el mapa
 */
public interface Colocable{ //Esto lo hacemos por si en un futuro queremos implementar diferentes formas de posicionamiento de barcos
    /**
    * Metodo para implementar colocar segun como se quiera
    * @param p1 Jugador al que se le va a colocar la ficha
    * @param position Lugar inicial de la ficha
    * @param option Direccion a la que se coloca la ficha
    * @see Jugador
    * @see Posicion
    */
    void colocar(Jugador p1, Posicion position, int option);
}
