
public class Posicion {
    private int fila,columna;
    
    public Posicion(int a,int b){
        this.fila = a;
        this.columna = b;
    }

    public int getFila(){
        return this.fila;
    }

    public int getColumna(){
        return this.columna;
    }
}
