public class Restos extends Fichas {
    
    public Restos(){
        super(1, 'X');
    }

}
